package engine.helper;

public enum GameStatus {
    RUNNING,
    WIN,
    LOSE,
    TIME_OUT
}
